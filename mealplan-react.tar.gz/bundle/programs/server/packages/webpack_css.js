(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/webpack_css/webpack.config.js                                                                    //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var weight = 200;                                                                                            // 1
                                                                                                             // 2
function dependencies(settings) {                                                                            // 3
  return {                                                                                                   // 4
    devDependencies: {                                                                                       // 5
      'style-loader' : '^0.13.0',                                                                            // 6
      'css-loader': '^0.23.0',                                                                               // 7
      'extract-text-webpack-plugin': '^0.9.1'                                                                // 8
    }                                                                                                        // 9
  };                                                                                                         // 10
}                                                                                                            // 11
                                                                                                             // 12
function config(settings, require) {                                                                         // 13
  var cssLoader = '';                                                                                        // 14
  var loaders = [];                                                                                          // 15
  var plugins = [];                                                                                          // 16
  var moduleStr = (settings.css && settings.css.module) ? 'module&' : '';                                    // 17
                                                                                                             // 18
  if (settings.isDebug) {                                                                                    // 19
    if (settings.platform === 'server') {                                                                    // 20
      cssLoader = 'css/locals?' + moduleStr + 'localIdentName=[name]__[local]__[hash:base64:5]';             // 21
    } else {                                                                                                 // 22
      cssLoader = 'style!css?' + moduleStr + 'localIdentName=[name]__[local]__[hash:base64:5]';              // 23
    }                                                                                                        // 24
  } else {                                                                                                   // 25
    if (settings.platform === 'server') {                                                                    // 26
      cssLoader = 'css/locals?' + moduleStr + 'localIdentName=[hash:base64:5]';                              // 27
    } else {                                                                                                 // 28
      var ExtractTextPlugin = require('extract-text-webpack-plugin');                                        // 29
      plugins.push(new ExtractTextPlugin('style.css'));                                                      // 30
      cssLoader = ExtractTextPlugin.extract('style', 'css?' + moduleStr + 'localIdentName=[hash:base64:5]');
    }                                                                                                        // 32
  }                                                                                                          // 33
                                                                                                             // 34
  if (cssLoader) {                                                                                           // 35
    loaders.push({ test: /\.css$/, loader: cssLoader });                                                     // 36
  }                                                                                                          // 37
                                                                                                             // 38
  return {                                                                                                   // 39
    loaders: loaders,                                                                                        // 40
    plugins: plugins,                                                                                        // 41
    extensions: ['.css']                                                                                     // 42
  };                                                                                                         // 43
}                                                                                                            // 44
                                                                                                             // 45
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['webpack:css'] = {};

})();

//# sourceMappingURL=webpack_css.js.map

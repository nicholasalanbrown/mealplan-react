(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var React = Package['react-runtime'].React;
var ReactDOM = Package['react-runtime'].ReactDOM;
var ReactDOMServer = Package['react-runtime'].ReactDOMServer;
var ReactMeteorData = Package['react-meteor-data'].ReactMeteorData;
var babelHelpers = Package['babel-runtime'].babelHelpers;

/* Package-scope variables */
var BlazeToReact;

(function(){

///////////////////////////////////////////////////////////////////////////////
//                                                                           //
// packages/thereactivestack_blazetoreact/lib/BlazeToReact-server.jsx        //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////
                                                                             //
// Blaze templates are not loaded server-side, we cannot do server-rendering
// We make sure the render is the same as on the client initially            //
                                                                             //
var DummyElement = React.createClass({                                       // 4
  displayName: "DummyElement",                                               //
                                                                             //
  render: function () {                                                      // 5
    return React.createElement("span", null);                                // 6
  }                                                                          //
});                                                                          //
                                                                             //
BlazeToReact = function (name, options) {                                    // 10
  if (!options) {                                                            // 11
    options = {};                                                            // 12
  }                                                                          //
                                                                             //
  if (!options.container) {                                                  // 15
    options.container = React.createElement("span", null);                   // 16
  }                                                                          //
                                                                             //
  return React.createClass({                                                 // 19
    render: function () {                                                    // 20
      return options.container;                                              // 21
    }                                                                        //
  });                                                                        //
};                                                                           //
///////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['thereactivestack:blazetoreact'] = {
  BlazeToReact: BlazeToReact
};

})();

//# sourceMappingURL=thereactivestack_blazetoreact.js.map

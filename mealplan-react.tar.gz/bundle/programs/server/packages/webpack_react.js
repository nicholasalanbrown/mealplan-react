(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/webpack_react/webpack.config.js                                                      //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
var weight = 100;                                                                                // 1
                                                                                                 // 2
function dependencies() {                                                                        // 3
  return {                                                                                       // 4
    dependencies: {                                                                              // 5
      // React has to be there for peerDependencies every though we are using the Meteor package
      'react': '~0.14.1',                                                                        // 7
    },                                                                                           // 8
    devDependencies: {                                                                           // 9
      'babel': '^6.3.26',                                                                        // 10
      'babel-core': '^6.3.26',                                                                   // 11
      'babel-loader' : '^6.2.0',                                                                 // 12
      'babel-preset-react': '^6.3.13',                                                           // 13
      'babel-preset-es2015': '^6.3.13',                                                          // 14
      'babel-preset-stage-0': '^6.3.13',                                                         // 15
      'babel-plugin-transform-decorators-legacy': '^1.3.2',                                      // 16
      'babel-plugin-add-module-exports': '^0.1.2',                                               // 17
      'babel-plugin-react-transform': '^2.0.0',                                                  // 18
      'react-transform-hmr' : '^1.0.1',                                                          // 19
      'react-transform-catch-errors': '^1.0.0',                                                  // 20
      'redbox-react': '^1.2.0'                                                                   // 21
    }                                                                                            // 22
  };                                                                                             // 23
}                                                                                                // 24
                                                                                                 // 25
function config(settings) {                                                                      // 26
  var fs = Npm.require('fs');                                                                    // 27
  var path = Npm.require('path');                                                                // 28
  var babelSettings = {};                                                                        // 29
                                                                                                 // 30
  var CWD = path.resolve('./');                                                                  // 31
                                                                                                 // 32
  if (fs.existsSync(CWD + '/.babelrc')) {                                                        // 33
    var babelrc = fs.readFileSync(CWD + '/.babelrc');                                            // 34
    babelSettings = JSON.parse(babelrc);                                                         // 35
  }                                                                                              // 36
                                                                                                 // 37
  if (!babelSettings.presets) {                                                                  // 38
    babelSettings.presets = [];                                                                  // 39
  }                                                                                              // 40
                                                                                                 // 41
  if (!babelSettings.plugins) {                                                                  // 42
    babelSettings.plugins = [];                                                                  // 43
  }                                                                                              // 44
                                                                                                 // 45
  if (babelSettings.presets.indexOf('react') < 0) {                                              // 46
    babelSettings.presets.push('react');                                                         // 47
  }                                                                                              // 48
                                                                                                 // 49
  if (babelSettings.presets.indexOf('es2015') < 0) {                                             // 50
    babelSettings.presets.push('es2015');                                                        // 51
  }                                                                                              // 52
                                                                                                 // 53
  if (babelSettings.presets.indexOf('stage-0') < 0 &&                                            // 54
      babelSettings.presets.indexOf('stage-1') < 0 &&                                            // 55
      babelSettings.presets.indexOf('stage-2') < 0 &&                                            // 56
      babelSettings.presets.indexOf('stage-3') < 0) {                                            // 57
    babelSettings.presets.push('stage-0');                                                       // 58
  }                                                                                              // 59
                                                                                                 // 60
  if (settings.babel && settings.babel.plugins) {                                                // 61
    babelSettings.plugins = babelSettings.plugins.concat(settings.babel.plugins);                // 62
  }                                                                                              // 63
                                                                                                 // 64
  if (babelSettings.plugins.indexOf('transform-decorators-legacy') < 0) {                        // 65
    babelSettings.plugins.push('transform-decorators-legacy');                                   // 66
  }                                                                                              // 67
                                                                                                 // 68
  if (babelSettings.plugins.indexOf('add-module-exports') < 0) {                                 // 69
    babelSettings.plugins.push('add-module-exports');                                            // 70
  }                                                                                              // 71
                                                                                                 // 72
  if (settings.isDebug && settings.platform !== 'server') {                                      // 73
    var transforms = [{                                                                          // 74
      transform: 'react-transform-hmr',                                                          // 75
      imports: ['react'],                                                                        // 76
      locals: ['module']                                                                         // 77
    }];                                                                                          // 78
                                                                                                 // 79
    if (settings.babel && !settings.babel.disableRedbox) {                                       // 80
      transforms.push({                                                                          // 81
        transform: 'react-transform-catch-errors',                                               // 82
        imports: ['react', 'redbox-react']                                                       // 83
      });                                                                                        // 84
    }                                                                                            // 85
                                                                                                 // 86
    babelSettings.plugins.push(['react-transform', { transforms: transforms }]);                 // 87
  }                                                                                              // 88
                                                                                                 // 89
  return {                                                                                       // 90
    loaders: [                                                                                   // 91
      { test: /\.jsx?$/, loader: 'babel', query: babelSettings, exclude: /node_modules/ }        // 92
    ],                                                                                           // 93
    extensions: ['.js', '.jsx'],                                                                 // 94
    externals: settings.packages.indexOf('react-runtime') < 0 ? {} : {                           // 95
      'react-addons-transition-group': 'React.addons.TransitionGroup',                           // 96
      'react-addons-css-transition-group': 'React.addons.CSSTransitionGroup',                    // 97
      'react-addons-linked-state-mixin': 'React.addons.LinkedStateMixin',                        // 98
      'react-addons-create-fragment': 'React.addons.createFrament',                              // 99
      'react-addons-update': 'React.addons.update',                                              // 100
      'react-addons-pure-render-mixin': 'React.addons.PureRenderMixin',                          // 101
      'react-addons-test-utils': 'React.addons.TestUtils',                                       // 102
      'react-addons-perf': 'React.addons.Perf'                                                   // 103
    }                                                                                            // 104
  };                                                                                             // 105
}                                                                                                // 106
                                                                                                 // 107
///////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['webpack:react'] = {};

})();

//# sourceMappingURL=webpack_react.js.map

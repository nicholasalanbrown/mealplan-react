(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['webpack:core-config'] = {};

})();

//# sourceMappingURL=webpack_core-config.js.map

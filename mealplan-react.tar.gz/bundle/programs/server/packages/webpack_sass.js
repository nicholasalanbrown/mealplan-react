(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/webpack_sass/webpack.config.js                                                                   //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var weight = 300;                                                                                            // 1
                                                                                                             // 2
function dependencies(settings) {                                                                            // 3
  return {                                                                                                   // 4
    devDependencies: {                                                                                       // 5
      'style-loader' : '^0.13.0',                                                                            // 6
      'css-loader': '^0.23.0',                                                                               // 7
      'sass-loader': '^3.1.2',                                                                               // 8
      'node-sass': '^3.4.2'                                                                                  // 9
    }                                                                                                        // 10
  };                                                                                                         // 11
}                                                                                                            // 12
                                                                                                             // 13
function config(settings, require) {                                                                         // 14
  var cssLoader = '';                                                                                        // 15
  var loaders = [];                                                                                          // 16
  var plugins = [];                                                                                          // 17
  var moduleStr = (settings.css && settings.css.module) ? 'module&' : '';                                    // 18
                                                                                                             // 19
  if (settings.isDebug) {                                                                                    // 20
    if (settings.platform === 'server') {                                                                    // 21
      cssLoader = 'css/locals?' + moduleStr + 'localIdentName=[name]__[local]__[hash:base64:5]';             // 22
    } else {                                                                                                 // 23
      cssLoader = 'style!css?' + moduleStr + 'localIdentName=[name]__[local]__[hash:base64:5]';              // 24
    }                                                                                                        // 25
  } else {                                                                                                   // 26
    if (settings.platform === 'server') {                                                                    // 27
      cssLoader = 'css/locals?' + moduleStr + 'localIdentName=[hash:base64:5]';                              // 28
    } else {                                                                                                 // 29
      var ExtractTextPlugin = require('extract-text-webpack-plugin');                                        // 30
      plugins.push(new ExtractTextPlugin('style.css'));                                                      // 31
      cssLoader = ExtractTextPlugin.extract('style', 'css?' + moduleStr + 'localIdentName=[hash:base64:5]');
    }                                                                                                        // 33
  }                                                                                                          // 34
                                                                                                             // 35
  if (cssLoader) {                                                                                           // 36
    loaders.push({ test: /\.scss$/, loader: cssLoader + '!sass?' + JSON.stringify(settings.sass || {}) });   // 37
  }                                                                                                          // 38
                                                                                                             // 39
  return {                                                                                                   // 40
    loaders: loaders,                                                                                        // 41
    plugins: plugins,                                                                                        // 42
    extensions: ['.scss']                                                                                    // 43
  };                                                                                                         // 44
}                                                                                                            // 45
                                                                                                             // 46
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['webpack:sass'] = {};

})();

//# sourceMappingURL=webpack_sass.js.map

(function(){// This file is sent directly to Meteor without going through Webpack
// You can initialize anything you need before your app start here

FlowRouter.wait();

}).call(this);

//# sourceMappingURL=meteor.startup.js.map
